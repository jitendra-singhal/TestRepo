package com.ctsms.authentication.service;

import java.util.Optional;

import com.ctsms.authentication.dto.User;

public interface AuthenticationService {
	public User registerUser(User user);
	public Optional<User> getUserByEmail(String email);
}
