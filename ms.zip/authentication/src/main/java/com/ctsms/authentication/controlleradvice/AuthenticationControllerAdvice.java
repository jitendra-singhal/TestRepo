package com.ctsms.authentication.controlleradvice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.exception.EmailAlreadyExistsException;
import com.ctsms.authentication.response.error.ErrorResponse;

@ControllerAdvice
public class AuthenticationControllerAdvice {
	
	@ExceptionHandler(EmailAlreadyExistsException.class)
	public ResponseEntity<?> handleMethodArgumentTypeMismatchException(EmailAlreadyExistsException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
	}
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
	}
	
	/*
	 * @ExceptionHandler(Exception.class) public ResponseEntity<?>
	 * handleGenericException(Exception e){
	 * 
	 * ErrorResponse errorResponse = new ErrorResponse();
	 * errorResponse.setErrorMessage(e.getMessage()); return
	 * ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
	 * }
	 */
}
