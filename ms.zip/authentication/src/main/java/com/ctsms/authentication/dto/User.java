package com.ctsms.authentication.dto;

import com.ctsms.authentication.utils.ValidEmail;
import com.ctsms.authentication.utils.ValidPassword;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class User {
	
	@Id
	@ValidEmail
	private String email;
	
	@ValidPassword
	private String password;

}
