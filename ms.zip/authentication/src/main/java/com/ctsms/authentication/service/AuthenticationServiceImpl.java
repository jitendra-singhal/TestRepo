package com.ctsms.authentication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctsms.authentication.dto.LoginResponse;
import com.ctsms.authentication.dto.User;
import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.repo.AuthenticationRepository;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	@Autowired
	private AuthenticationRepository authenticationRepository;
	
	@Override
	public User registerUser(User user){
		return authenticationRepository.save(user);
	}

	@Override
	public Optional<User> getUserByEmail(String email) {
		return authenticationRepository.findById(email);
	}




}
