package com.ctsms.userprofile.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ctsms.authentication.dto.User;

public interface ProfileRepository  extends JpaRepository<UserProfile, String>{

}
