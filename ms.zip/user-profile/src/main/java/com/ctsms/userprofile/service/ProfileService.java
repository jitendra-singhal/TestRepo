package com.ctsms.userprofile.service;

import java.util.Optional;

import com.ctsms.authentication.dto.User;

public interface ProfileService {
	public UserProfile registerUser(UserProfile user);
	public Optional<UserProfile> getUserByEmail(String email);
}
