package com.ctsms.userprofile.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctsms.authentication.dto.LoginResponse;
import com.ctsms.authentication.dto.User;
import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.repo.AuthenticationRepository;

@Service
public class ProfileServiceImpl implements ProfileService {

	@Autowired
	private ProfileRepository authenticationRepository;
	
	@Override
	public UserProfile registerUser(UserProfile user){
		return authenticationRepository.save(user);
	}

	@Override
	public Optional<UserProfile> getUserByEmail(String email) {
		return authenticationRepository.findById(email);
	}




}
