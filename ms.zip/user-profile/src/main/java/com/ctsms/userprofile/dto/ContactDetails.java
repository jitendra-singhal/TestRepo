package com.ctsms.userprofile.dto;

import lombok.Data;

@Data
public class ContactDetails {
	
	private String token;
	
	private String message;

}
