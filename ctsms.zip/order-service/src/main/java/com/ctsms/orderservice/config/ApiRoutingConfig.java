package com.ctsms.orderservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.cloud.gateway.*;

@Configuration
public class ApiRoutingConfig {
	
	public Route

}
